<template>
    <v-sheet height="100svh">
        <div class="text-center text-h2 py-16">Coming soon!</div>
        <v-img class="mx-auto" src="/img/UitBest.png" width="33%" />
    </v-sheet>
</template>

<script setup>

</script>
